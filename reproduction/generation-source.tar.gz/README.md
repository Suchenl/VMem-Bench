# Frozen paper generation source

Code and Track-B inputs from commit 0b41d3df8d5c2b53ecc491ad00c769db2fa24a8b.
See the outer release REPRODUCE.md for dependencies, cohort and limitations.
This is a generated source artifact, not an independently maintained implementation.
