# Track B Stage-1 — English story run order (shortest first)

Assumptions: 30 parallel GPU slots, frames_per_segment=21, steps memflow=5/longlive=10/iamflow=5, per-segment sec memflow=20/longlive=55/iamflow=60, load=150s/job, realistic factor x1.6.
These per-segment rates are ESTIMATES; regenerate with measured rates after the pilot.

Pick a cutoff K = the number of shortest stories to run (each story runs all 3 systems).

| K (stories) | story_id | n_seg | cum_seg | cum GPU·h | wall ideal (h) | wall realistic (h) |
|---:|---|---:|---:|---:|---:|---:|
| 1 | 0009_tea_horse_station | 68 | 68 | 2.7 | 1.2 | 1.9 |
| 2 | 0010_subway_violinist | 68 | 136 | 5.3 | 1.2 | 1.9 |
| 3 | 0011_greenhouse_botanist | 68 | 204 | 8.0 | 1.2 | 1.9 |
| 4 | 0004_silk_road_caravan | 71 | 275 | 10.8 | 1.2 | 2.0 |
| 5 | 0005_opera_mask_atelier | 71 | 346 | 13.6 | 1.2 | 2.0 |
| 6 | 0006_harbor_ice_cutter | 71 | 417 | 16.4 | 1.2 | 2.0 |
| 7 | 0008_clocktower_horologist | 71 | 488 | 19.2 | 1.2 | 2.0 |
| 8 | 0007_bamboo_paper_mill | 72 | 560 | 22.0 | 1.2 | 2.0 |
| 9 | 0014_forge_swordsmith | 84 | 644 | 25.3 | 1.4 | 2.3 |
| 10 | 0012_puppet_shadow_troupe | 85 | 729 | 28.6 | 1.5 | 2.3 |
| 11 | 0018_train_porter | 85 | 814 | 31.9 | 1.5 | 2.3 |
| 12 | 0016_hot_spring_innkeeper | 86 | 900 | 35.2 | 1.5 | 2.4 |
| 13 | 0019_lantern_festival_maker | 86 | 986 | 38.6 | 1.5 | 2.4 |
| 14 | 0001_lighthouse_keeper | 87 | 1073 | 42.0 | 1.5 | 2.4 |
| 15 | 0003_desert_archaeologist | 87 | 1160 | 45.4 | 1.5 | 2.4 |
| 16 | 0002_night_market_courier | 88 | 1248 | 48.8 | 1.6 | 2.6 |
| 17 | 0013_salt_flat_photographer | 88 | 1336 | 52.2 | 1.7 | 2.8 |
| 18 | 0017_reef_diver | 88 | 1424 | 55.6 | 1.9 | 3.0 |
| 19 | 0015_library_night_archivist | 90 | 1514 | 59.1 | 2.0 | 3.2 |
| 20 | 0024_circus_acrobat | 111 | 1625 | 63.4 | 2.1 | 3.4 |
| 21 | 0022_vineyard_cellarer | 113 | 1738 | 67.8 | 2.3 | 3.6 |
| 22 | 0026_rice_terrace_farmer | 114 | 1852 | 72.2 | 2.4 | 3.9 |
| 23 | 0020_observatory_intern | 115 | 1967 | 76.6 | 2.6 | 4.1 |
| 24 | 0021_pottery_kiln_master | 115 | 2082 | 81.1 | 2.7 | 4.3 |
| 25 | 0027_radio_station_dj | 116 | 2198 | 85.5 | 2.9 | 4.6 |
| 26 | 0023_firefighter_rookies | 118 | 2316 | 90.1 | 3.0 | 4.8 |
| 27 | 0025_museum_night_guard | 119 | 2435 | 94.7 | 3.2 | 5.1 |
| 28 | 0028_shipyard_welder | 127 | 2562 | 99.6 | 3.3 | 5.3 |
| 29 | 0029_ink_wash_painter | 131 | 2693 | 104.6 | 3.5 | 5.6 |
| 30 | 0030_ski_patrol | 131 | 2824 | 109.7 | 3.7 | 5.8 |
| 31 | 0032_beekeeper_meadow | 131 | 2955 | 114.7 | 3.8 | 6.1 |
| 32 | 0031_spice_bazaar_cook | 134 | 3089 | 119.8 | 4.0 | 6.4 |
| 33 | 0033_film_projectionist | 134 | 3223 | 125.0 | 4.2 | 6.7 |
| 34 | 0034_canal_boatman | 134 | 3357 | 130.1 | 4.3 | 6.9 |
| 35 | 0035_windmill_miller | 139 | 3496 | 135.5 | 4.5 | 7.2 |
| 36 | 0036_calligraphy_school | 167 | 3663 | 141.9 | 4.7 | 7.6 |
| 37 | 0037_mine_lamp_checker | 168 | 3831 | 148.3 | 4.9 | 7.9 |
| 38 | 0038_balloon_festival | 168 | 3999 | 154.7 | 5.2 | 8.3 |
| 39 | 0040_luthier_workshop | 168 | 4167 | 161.1 | 5.4 | 8.6 |
| 40 | 0041_border_customs | 169 | 4336 | 167.6 | 5.6 | 8.9 |
| 41 | 0042_glassblower_studio | 169 | 4505 | 174.1 | 5.8 | 9.3 |
| 42 | 0043_orchard_grafting | 170 | 4675 | 180.6 | 6.0 | 9.6 |
| 43 | 0039_sushi_counter_apprentice | 171 | 4846 | 187.1 | 6.2 | 10.0 |
| 44 | 0045_tide_pool_naturalist | 176 | 5022 | 193.8 | 6.5 | 10.3 |
| 45 | 0044_subway_map_designer | 182 | 5204 | 200.8 | 6.7 | 10.7 |
| 46 | 0046_monastery_bell_ringer | 185 | 5389 | 207.8 | 6.9 | 11.1 |
| 47 | 0047_cargo_crane_operator | 188 | 5577 | 215.0 | 7.2 | 11.5 |
| 48 | 0048_embroidery_guild | 191 | 5768 | 222.3 | 7.4 | 11.9 |
| 49 | 0049_volcano_geologist | 194 | 5962 | 229.7 | 7.7 | 12.3 |
| 50 | 0050_planetarium_guide | 197 | 6159 | 237.2 | 7.9 | 12.7 |
