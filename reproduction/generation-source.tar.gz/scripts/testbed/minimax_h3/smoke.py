#!/usr/bin/env python
"""GPU smoke for the MiniMax-H3 Turbo backend: reference fidelity, zero-reference, seed determinism, timing.

    python scripts/testbed/minimax_h3/smoke.py --endpoints <endpoint_dir|urls> \
        --prompts assets/trackB/en/sut_prompts/0001_lighthouse_keeper_name_anchored.json \
        --ref-dir <run>/pipeline/retrieval_read/oracle_frames --out <dir>

Each case is ``name:segment_index:ref_shots:seed[:HxW[:ref_short_edge]]``; ``ref_shots`` is ``-`` or ``+``-joined shot ids
whose ``c%05d_mid.png`` stills in ``--ref-dir`` become the references. Writes ``<out>/<name>/seg_*.mp4``,
a contact sheet per case (references | frames 0/30/60/90/120), and ``<out>/smoke_summary.json``.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "src"))

from vmem_bench.testbed.backends.base import RealizationRequest  # noqa: E402
from vmem_bench.testbed.backends.minimax_h3 import MiniMaxH3TurboBackend  # noqa: E402

DEFAULT_CASES = [
    "t2v_s0_a:0:-:2026",
    "t2v_s0_b:0:-:2026",
    "t2v_s0_seed2027:0:-:2027",
    "ref1_s1:1:0:2026",
    "ref2_s3:3:0+2:2026",
    "ref2_s3_rerun:3:0+2:2026",
    "ref3_s25:25:9+10+15:2026",
    "t2v_s3:3:-:2026",
    "t2v_s25:25:-:2026",
    "ref2_s3_480p:3:0+2:2026:480x832",
]
SHEET_FRAMES = (0, 30, 60, 90, 120)


def read_frames(path: Path) -> list[np.ndarray]:
    import imageio.v2 as imageio

    reader = imageio.get_reader(str(path))
    try:
        return [np.asarray(f) for f in reader]
    finally:
        reader.close()


def contact_sheet(refs: list[Path], frames: list[np.ndarray], out: Path, cell_h: int = 240) -> None:
    from PIL import Image, ImageDraw

    def fit(img: Image.Image) -> Image.Image:
        w, h = img.size
        return img.resize((max(1, round(w * cell_h / h)), cell_h), Image.Resampling.LANCZOS)

    cells = [("ref%d" % (i + 1), fit(Image.open(p).convert("RGB"))) for i, p in enumerate(refs)]
    cells += [(f"f{k}", fit(Image.fromarray(frames[k]))) for k in SHEET_FRAMES if k < len(frames)]
    sheet = Image.new("RGB", (sum(c.width for _, c in cells) + 8 * len(cells), cell_h + 20), "white")
    x = 0
    draw = ImageDraw.Draw(sheet)
    for label, c in cells:
        sheet.paste(c, (x, 20))
        draw.text((x + 4, 4), label, fill="black")
        x += c.width + 8
    out.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(out)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--endpoints", required=True)
    p.add_argument("--prompts", required=True)
    p.add_argument("--ref-dir", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--case", action="append", default=None)
    args = p.parse_args()

    segments = json.loads(Path(args.prompts).read_text(encoding="utf-8"))["segments"]
    out_root = Path(args.out)
    backends: dict[tuple[int, int], MiniMaxH3TurboBackend] = {}
    rows, clips = [], {}
    for spec in args.case or DEFAULT_CASES:
        parts = spec.split(":")
        name, seg, shots, seed = parts[0], int(parts[1]), parts[2], int(parts[3])
        h, w = (int(v) for v in parts[4].split("x")) if len(parts) > 4 and parts[4] else (704, 1280)
        edge = int(parts[5]) if len(parts) > 5 else 768
        be = backends.get((h, w, edge))
        if be is None:
            be = backends[(h, w, edge)] = MiniMaxH3TurboBackend(args.endpoints, height=h, width=w,
                                                                ref_image_short_edge=edge)
            be.start()
        refs = tuple() if shots == "-" else tuple(Path(args.ref_dir) / f"c{int(s):05d}_mid.png" for s in shots.split("+"))
        req = RealizationRequest(segment_id=seg, prompt=segments[seg]["prompt"], references=refs,
                                 seed=seed, out_dir=out_root / name)
        t0 = time.time()
        res = be.realize(req)
        wall = time.time() - t0
        frames = read_frames(res.clip)
        clips[name] = frames
        contact_sheet(list(refs), frames, out_root / "sheets" / f"{name}.png")
        (out_root / name / "prompt.txt").write_text(res.meta["prompt"], encoding="utf-8")
        row = {k: res.meta.get(k) for k in ("elapsed_sec", "generate_sec", "queue_wait_sec", "peak_vram_gib",
                                            "reserved_vram_gib", "rendered_frames", "delivered_frames",
                                            "delivered_size", "render_frames_sha256", "cached", "job_index")}
        row.update(name=name, segment=seg, n_refs=len(refs), seed=seed, render=f"{h}x{w}", ref_short_edge=edge,
                   wall_sec=round(wall, 2),
                   clip=str(res.clip), sheet=str(out_root / "sheets" / f"{name}.png"))
        rows.append(row)
        print(json.dumps(row), flush=True)

    def diff(a: str, b: str) -> dict:
        if a not in clips or b not in clips:
            return {}
        x, y = np.stack(clips[a]).astype(np.int16), np.stack(clips[b]).astype(np.int16)
        d = np.abs(x - y)
        return {"pair": [a, b], "mean_abs_diff": round(float(d.mean()), 4), "max_abs_diff": int(d.max()),
                "identical_pixels_frac": round(float((d == 0).mean()), 4)}

    by = {r["name"]: r for r in rows}
    summary = {
        "cases": rows,
        "determinism": [
            {**diff("t2v_s0_a", "t2v_s0_b"),
             "render_sha_equal": by.get("t2v_s0_a", {}).get("render_frames_sha256") == by.get("t2v_s0_b", {}).get("render_frames_sha256")},
            {**diff("ref2_s3", "ref2_s3_rerun"),
             "render_sha_equal": by.get("ref2_s3", {}).get("render_frames_sha256") == by.get("ref2_s3_rerun", {}).get("render_frames_sha256")},
            diff("t2v_s0_a", "t2v_s0_seed2027"),
            diff("ref2_s3", "t2v_s3"),
            diff("ref3_s25", "t2v_s25"),
        ],
    }
    # Same request, same out -> server cache.
    if "ref1_s1" in by:
        be = next(iter(backends.values()))
        seg = by["ref1_s1"]["segment"]
        req = RealizationRequest(segment_id=seg, prompt=segments[seg]["prompt"],
                                 references=(Path(args.ref_dir) / "c00000_mid.png",), seed=2026,
                                 out_dir=out_root / "ref1_s1")
        t0 = time.time()
        summary["cache_hit"] = {"cached": be.realize(req).meta.get("cached"), "wall_sec": round(time.time() - t0, 3)}
    (out_root / "smoke_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary["determinism"], indent=1))
    print("cache:", summary.get("cache_hit"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
