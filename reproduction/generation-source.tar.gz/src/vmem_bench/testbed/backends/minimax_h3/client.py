"""``RealizationBackend`` client for resident MiniMax-H3 Ref2V Turbo servers.

The references go straight into the video model (no composed keyframe). The client turns the
segment instruction into an H3 prompt (:func:`build_h3_prompt`), posts it with the reference paths
to one of the discovered servers and returns the clip the server wrote under ``request.out_dir``.
Several runner threads may share one client; each call takes a free endpoint from the pool.
"""

from __future__ import annotations

import json
import os
import queue
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Sequence

from vmem_bench.testbed.backends.base import RealizationRequest, RealizationResult
from vmem_bench.testbed.backends.minimax_h3 import geometry as geo
from vmem_bench.testbed.backends.minimax_h3.geometry import MODEL_ID
from vmem_bench.testbed.backends.minimax_h3.prompt import PROMPT_FORMAT_VERSION, build_h3_prompt

ENDPOINTS_ENV = "VMEM_H3_ENDPOINTS"

# Resident servers sit on cluster-internal IPs; never route them through http(s)_proxy.
_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _get_json(url: str, timeout: float) -> dict[str, Any]:
    with _OPENER.open(url, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def healthy(url: str, *, timeout: float = 5.0) -> bool:
    try:
        info = _get_json(url.rstrip("/") + "/health", timeout)
    except (OSError, ValueError):
        return False
    return bool(info.get("ok")) and info.get("model") == MODEL_ID


def candidate_urls(spec: str | Path | Sequence[str]) -> list[str]:
    """Expand an endpoint spec without contacting anything.

    ``spec`` is a directory of server endpoint JSONs (``<model>_*.json`` with a ``url``), a text file
    with one URL per line (``#`` comments allowed), a comma-separated URL string, or a list of URLs.
    """
    if isinstance(spec, (list, tuple)):
        urls = [str(u).strip() for u in spec]
    else:
        path = Path(str(spec)).expanduser()
        if path.is_dir():
            urls = []
            for f in sorted(path.glob(f"{MODEL_ID}_*.json")):
                try:
                    urls.append(str(json.loads(f.read_text(encoding="utf-8"))["url"]))
                except (OSError, KeyError, TypeError, json.JSONDecodeError):
                    continue
        elif path.is_file():
            urls = [ln.split("#", 1)[0].strip() for ln in path.read_text(encoding="utf-8").splitlines()]
        else:
            urls = [u.strip() for u in str(spec).split(",")]
    return sorted({u.rstrip("/") for u in urls if u})


def discover_endpoints(spec: str | Path | Sequence[str], *, timeout: float = 5.0) -> list[str]:
    """Healthy MiniMax-H3 endpoints for ``spec`` (see :func:`candidate_urls`)."""
    return [u for u in candidate_urls(spec) if healthy(u, timeout=timeout)]


def build_request_body(request: RealizationRequest, *, out: Path, prompt: str, num_frames: int, fps: int,
                       height: int, width: int, out_height: int | None, out_width: int | None,
                       steps: int, ref_image_short_edge: int) -> dict[str, Any]:
    return {
        "prompt": prompt,
        "references": [str(Path(p).resolve()) for p in request.references],
        "seed": int(request.seed),
        "out": str(out.resolve()),
        "num_frames": int(num_frames),
        "fps": int(fps),
        "height": int(height),
        "width": int(width),
        "out_height": None if out_height is None else int(out_height),
        "out_width": None if out_width is None else int(out_width),
        "steps": int(steps),
        "ref_image_short_edge": int(ref_image_short_edge),
    }


class MiniMaxH3TurboBackend:
    """Realization backend: MiniMax-H3 Ref2V + 4-step Turbo LoRA, references into the video model."""

    name = "minimax_h3_turbo"

    def __init__(
        self,
        endpoints: str | Path | Sequence[str] | None = None,
        *,
        num_frames: int = geo.NUM_FRAMES,
        fps: int = geo.FPS,
        height: int = geo.RENDER_HEIGHT,
        width: int = geo.RENDER_WIDTH,
        out_height: int | None = geo.OUT_HEIGHT,
        out_width: int | None = geo.OUT_WIDTH,
        steps: int = geo.STEPS,
        ref_image_short_edge: int = geo.REF_IMAGE_SHORT_EDGE,
        duration_sec: float = geo.SEGMENT_SECONDS,
        max_references: int = 3,
        timeout_sec: float = 1800.0,
    ):
        self.endpoints_spec = endpoints if endpoints is not None else os.environ.get(ENDPOINTS_ENV)
        self.num_frames, self.fps = num_frames, fps
        self.height, self.width = height, width
        self.out_height, self.out_width = out_height, out_width
        self.steps, self.ref_image_short_edge = steps, ref_image_short_edge
        self.duration_sec, self.max_references = duration_sec, max_references
        self.timeout_sec = timeout_sec
        self.endpoints: list[str] = []
        self._pool: queue.Queue[str] | None = None

    def start(self) -> None:
        if self._pool is not None:
            return
        if not self.endpoints_spec:
            raise RuntimeError(f"no MiniMax-H3 endpoints: pass endpoints= or set ${ENDPOINTS_ENV}")
        urls = discover_endpoints(self.endpoints_spec)
        if not urls:
            raise RuntimeError(f"no healthy MiniMax-H3 endpoint in {self.endpoints_spec!r}")
        self.endpoints = urls
        self._pool = queue.Queue()
        for u in urls:
            self._pool.put(u)

    def stop(self) -> None:
        """Servers are shared and started out of band (serve.sh); only drop the pool."""
        self._pool = None

    def prompt_for(self, request: RealizationRequest) -> str:
        return build_h3_prompt(request.prompt, len(request.references), duration_sec=self.duration_sec)

    def body_for(self, request: RealizationRequest) -> dict[str, Any]:
        if len(request.references) > self.max_references:
            raise ValueError(f"{len(request.references)} references > max_references={self.max_references}")
        out = Path(request.out_dir) / f"seg_{int(request.segment_id):03d}.mp4"
        return build_request_body(
            request, out=out, prompt=self.prompt_for(request), num_frames=self.num_frames, fps=self.fps,
            height=self.height, width=self.width, out_height=self.out_height, out_width=self.out_width,
            steps=self.steps, ref_image_short_edge=self.ref_image_short_edge,
        )

    def _post(self, url: str, body: dict[str, Any]) -> dict[str, Any]:
        req = urllib.request.Request(url + "/v1/realize", data=json.dumps(body).encode("utf-8"),
                                     headers={"Content-Type": "application/json"}, method="POST")
        try:
            with _OPENER.open(req, timeout=self.timeout_sec) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"MiniMax-H3 {url} HTTP {exc.code}: {detail}") from exc
        except (OSError, ValueError) as exc:
            raise RuntimeError(f"MiniMax-H3 {url} request failed: {type(exc).__name__}: {exc}") from exc

    def realize(self, request: RealizationRequest) -> RealizationResult:
        if self._pool is None:
            self.start()
        assert self._pool is not None
        body = self.body_for(request)
        Path(request.out_dir).mkdir(parents=True, exist_ok=True)
        url = self._pool.get()
        try:
            meta = self._post(url, body)
        finally:
            self._pool.put(url)
        clip = Path(meta.get("clip") or body["out"])
        if not clip.is_file() or clip.stat().st_size == 0:
            raise RuntimeError(f"MiniMax-H3 {url} reported success but {clip} is missing or empty")
        meta = {**meta, "endpoint": url, "backend": self.name, "prompt_format": PROMPT_FORMAT_VERSION,
                "n_references": len(request.references)}
        return RealizationResult(clip=clip, keyframe=None, meta=meta)
