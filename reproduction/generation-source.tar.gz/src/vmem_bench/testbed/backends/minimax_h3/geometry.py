"""Clip geometry of the MiniMax-H3-Turbo pipeline, aligned with the paper's Wan2.2 pipeline.

The paper's shared generator (MemStrata ``configs/video_gen/wan22_ti2v5b_turbo.toml``) renders
121 frames at 24 fps (5.04 s, one Track-B segment) at 704x1280 and delivers 480x832. H3 also runs at
24 fps but snaps frame counts up to 17n+5, so 121 requested frames render as 124 and the clip is
trimmed back to the first 121. H3's native short side is 768; 704x1280 (both multiples of 32) is
the paper's render size and within H3's trained range, and the delivered clip is downscaled to the
paper's 480x832 so scorers see the same resolution for both pipelines.

Measured on one B200 (2026-09-27 smoke): 704x1280 costs ~61 s (0 refs) to ~80 s (3 refs) per segment,
480x832 ~20-32 s. ``REF_IMAGE_SHORT_EDGE`` is 768 rather than DiffSynth's 2048 default: 2048 made a
2-reference segment 2.3x slower (170 s) without a visible fidelity gain.
"""

from __future__ import annotations

MODEL_ID = "minimax_h3_ref2v_turbo"
NUM_FRAMES = 121
FPS = 24
RENDER_HEIGHT = 704
RENDER_WIDTH = 1280
OUT_HEIGHT = 480
OUT_WIDTH = 832
STEPS = 4
REF_IMAGE_SHORT_EDGE = 768
SEGMENT_SECONDS = 5.0


def aligned_frame_count(n: int) -> int:
    """Smallest 17k+5 >= n (H3's temporal VAE layout)."""
    current = max(int(n), 5)
    while current % 17 != 5:
        current += 1
    return current
